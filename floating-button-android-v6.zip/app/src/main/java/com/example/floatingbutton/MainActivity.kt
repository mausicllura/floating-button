package com.example.floatingbutton

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var srcSp: Spinner
    private lateinit var dstSp: Spinner
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val TUTORIAL = """
🔵 Круглая кнопка живёт поверх всех приложений. Тап — открыть меню из пяти кнопок. Перетащите куда угодно. Чтобы убрать: зажмите и тяните вниз на красный ✕.

⚙️ Настройки — язык видео (с какого переводить) и язык озвучки (на какой).

🎙️ Озвучка — выберите, что озвучить: звук видео (слушает микрофон), текст на экране или текст на фото и картинке.

🕘 История — всё, что озвучено, можно посмотреть и озвучить снова.

🌐 Перевод экрана — переводит весь текст, который сейчас виден в любом приложении.

🤫 Секретная кнопка — шутка: «перевод» врёт и показывает выдуманную рекламу про нейросети.

Перед началом выдайте разрешения ниже.
""".trimIndent()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val sc = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(28)) }
        sc.addView(col)
        fun tv(t: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.parseColor("#1D1B19"))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } }
        col.addView(tv("Плавающая кнопка", 28f, true))
        col.addView(tv("Озвучка и перевод видео, текста и фото поверх любых приложений.", 15f))
        col.addView(btn("Показать подсказки") { showTutorial() })
        col.addView(tv("1. Разрешения", 18f, true))
        col.addView(btn("Показывать поверх других приложений") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Разрешить микрофон") {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        col.addView(btn("Разрешить уведомления") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        })
        col.addView(btn("Включить службу доступа (текст экрана и фото)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        status = tv("", 14f); col.addView(status)
        col.addView(tv("2. Языки", 18f, true))
        col.addView(tv("С какого языка видео", 14f))
        srcSp = spinner(Prefs.src(this)); col.addView(srcSp)
        col.addView(tv("На какой язык озвучивать", 14f))
        dstSp = spinner(Prefs.dst(this)); col.addView(dstSp)
        col.addView(tv("3. Запуск", 18f, true))
        col.addView(btn("▶ Включить кнопку на экране") { start() })
        col.addView(btn("⏹ Выключить кнопку") { stopService(Intent(this, OverlayService::class.java)) })
        col.addView(tv("Если Android блокирует службу доступа у приложения не из магазина: Настройки → Приложения → Плавающая кнопка → ⋮ → «Разрешить ограниченные настройки».", 13f))
        setContentView(sc)
        if (!Prefs.tutorialDone(this)) showTutorial()
    }

    private fun spinner(sel: String) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Prefs.LANGS.map { it.second })
        setSelection(Prefs.LANGS.indexOfFirst { it.first == sel }.coerceAtLeast(0))
    }

    private fun saveLangs() = Prefs.setLangs(this, Prefs.LANGS[srcSp.selectedItemPosition].first, Prefs.LANGS[dstSp.selectedItemPosition].first)

    private fun start() {
        saveLangs()
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Сначала разрешите показ поверх других приложений", Toast.LENGTH_LONG).show(); return }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Кнопка включена. Откройте любое приложение.", Toast.LENGTH_LONG).show()
    }

    private fun showTutorial() {
        AlertDialog.Builder(this).setTitle("Как это работает").setMessage(TUTORIAL)
            .setPositiveButton("Понятно") { _, _ -> Prefs.setTutorialDone(this) }
            .setOnCancelListener { Prefs.setTutorialDone(this) }.show()
    }

    override fun onPause() { saveLangs(); super.onPause() }

    override fun onResume() {
        super.onResume()
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        fun m(b: Boolean) = if (b) "✓" else "✕"
        status.text = "${m(Settings.canDrawOverlays(this))} поверх приложений   ${m(mic)} микрофон   ${m(acc)} служба доступа"
    }
}
