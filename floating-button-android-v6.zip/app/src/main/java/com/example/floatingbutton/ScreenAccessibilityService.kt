package com.example.floatingbutton

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Читает текст на экране других приложений и делает снимок экрана для OCR. */
class ScreenAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: ScreenAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun collectText(): String {
        val root = rootInActiveWindow ?: return ""
        val set = LinkedHashSet<String>()
        walk(root, set)
        return set.joinToString("\n")
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableSet<String>) {
        if (n == null) return
        if (n.isVisibleToUser) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) out.add(t)
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    fun screenshot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cb(bmp)
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }
}
