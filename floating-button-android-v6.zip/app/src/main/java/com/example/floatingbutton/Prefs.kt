package com.example.floatingbutton

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    val LANGS = listOf(
        "ru" to "Русский", "en" to "English", "es" to "Español", "fr" to "Français",
        "de" to "Deutsch", "it" to "Italiano", "pt" to "Português", "zh" to "中文",
        "ja" to "日本語", "ko" to "한국어", "tr" to "Türkçe", "ar" to "العربية",
        "hi" to "हिन्दी", "uk" to "Українська", "pl" to "Polski"
    )

    private fun sp(c: Context) = c.getSharedPreferences("fb", Context.MODE_PRIVATE)
    fun name(code: String) = LANGS.firstOrNull { it.first == code }?.second ?: code
    fun src(c: Context) = sp(c).getString("src", "en")!!
    fun dst(c: Context) = sp(c).getString("dst", "ru")!!
    fun setLangs(c: Context, s: String, d: String) =
        sp(c).edit().putString("src", s).putString("dst", d).apply()

    fun tutorialDone(c: Context) = sp(c).getBoolean("tut", false)
    fun setTutorialDone(c: Context) = sp(c).edit().putBoolean("tut", true).apply()
    fun hintOpens(c: Context) = sp(c).getInt("hints", 0)
    fun bumpHint(c: Context) = sp(c).edit().putInt("hints", hintOpens(c) + 1).apply()

    fun addHistory(c: Context, original: String, translated: String, s: String, d: String) {
        val a = JSONArray(sp(c).getString("hist", "[]"))
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("o", original.take(500))
            .put("tr", translated).put("s", s).put("d", d))
        val out = JSONArray()
        for (i in maxOf(0, a.length() - 100) until a.length()) out.put(a.get(i))
        sp(c).edit().putString("hist", out.toString()).apply()
    }

    fun history(c: Context): List<JSONObject> {
        val a = JSONArray(sp(c).getString("hist", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    fun clearHistory(c: Context) = sp(c).edit().putString("hist", "[]").apply()
}
