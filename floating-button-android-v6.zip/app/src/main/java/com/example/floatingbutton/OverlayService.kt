package com.example.floatingbutton

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.view.ContextThemeWrapper
import android.widget.*
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var eng: Engine
    private lateinit var ui: Context
    private val main = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var kill: TextView? = null
    private val sats = mutableListOf<View>()
    private var panel: View? = null
    private var menuOpen = false
    private var listening = false
    private var secret = false
    private var fi = 0

    private val sw get() = resources.displayMetrics.widthPixels
    private val sh get() = resources.displayMetrics.heightPixels
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val bubbleSize get() = px(60)

    private val FAKE = listOf(
        "Реклама: мы просто хотим заработать и обучаем самых неопытных пользоваться нейросетью. Хотя моя кошка уже освоила нейросеть и без нас.",
        "Реклама: учим пользоваться нейросетью! Цель простая — заработать. Кошка, кстати, справляется лучше.",
        "Рекламная пауза: обучаем нейросетям всех подряд. Мы просто хотим заработать. Кошка автора уже в курсе.",
        "Реклама курса по нейросетям. Честно: мы хотим заработать. Даже кошка справилась бы бесплатно."
    )

    private val ITEMS = listOf(
        "⚙️" to "Настройки языков",
        "🎙️" to "Озвучка: выберите, что озвучить",
        "🕘" to "История озвучки",
        "🌐" to "Перевести текст экрана",
        "🤫" to "Секретная кнопка (шутка)"
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ui = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Light)
        eng = Engine(applicationContext)
        startFg()
        createBubble()
    }

    private fun startFg() {
        val ch = "fb"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Плавающая кнопка", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Плавающая кнопка работает")
            .setContentText("Нажмите, чтобы открыть настройки")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun lp(w: Int, h: Int, x: Int, y: Int, focus: Boolean = false) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            (if (focus) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun circle(text: String, color: Int, sizeDp: Int, sp: Float) = TextView(ui).apply {
        this.text = text; gravity = Gravity.CENTER; textSize = sp; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        elevation = px(6).toFloat()
    }

    private fun rm(v: View?) { if (v != null) try { wm.removeView(v) } catch (_: Exception) {} }

    // ---------- кнопка ----------
    private fun createBubble() {
        val b = circle("✦", Color.parseColor("#2F5BFF"), 60, 26f)
        bubble = b
        bubbleLp = lp(bubbleSize, bubbleSize, sw - bubbleSize - px(8), sh / 2 - bubbleSize / 2)
        wm.addView(b, bubbleLp)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bubbleLp.x; oy = bubbleLp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (!moved && hypot(dx, dy) > px(8)) { moved = true; closeMenu(); showKill(true) }
                        if (moved) {
                            bubbleLp.x = (ox + dx).toInt().coerceIn(0, sw - bubbleSize)
                            bubbleLp.y = (oy + dy).toInt().coerceIn(0, sh - bubbleSize)
                            wm.updateViewLayout(v, bubbleLp)
                            kill?.alpha = if (overKill()) 1f else 0.7f
                            kill?.scaleX = if (overKill()) 1.3f else 1f
                            kill?.scaleY = kill?.scaleX ?: 1f
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            val del = overKill()
                            showKill(false)
                            if (del) { stopSelf() } else {
                                bubbleLp.x = if (bubbleLp.x + bubbleSize / 2 < sw / 2) px(8) else sw - bubbleSize - px(8)
                                wm.updateViewLayout(v, bubbleLp)
                            }
                        } else toggleMenu()
                    }
                    MotionEvent.ACTION_CANCEL -> showKill(false)
                }
                return true
            }
        })
    }

    private fun showKill(show: Boolean) {
        if (show && kill == null) {
            val k = circle("✕", Color.parseColor("#E5383B"), 64, 28f)
            kill = k
            wm.addView(k, lp(px(64), px(64), sw / 2 - px(32), sh - px(64) - px(90)))
        } else if (!show) { rm(kill); kill = null }
    }

    private fun overKill(): Boolean {
        val k = kill ?: return false
        val kl = (k.layoutParams as WindowManager.LayoutParams)
        val kx = kl.x + px(32); val ky = kl.y + px(32)
        return hypot((bubbleLp.x + bubbleSize / 2 - kx).toDouble(), (bubbleLp.y + bubbleSize / 2 - ky).toDouble()) < px(70)
    }

    // ---------- меню из 5 кнопок ----------
    private fun toggleMenu() { if (menuOpen) closeMenu() else openMenu() }

    private fun openMenu() {
        menuOpen = true
        val hints = Prefs.hintOpens(this) < 2
        Prefs.bumpHint(this)
        val cx = bubbleLp.x + bubbleSize / 2f
        val cy = bubbleLp.y + bubbleSize / 2f
        val base = atan2(sh / 2f - cy, sw / 2f - cx)
        val offs = listOf(-1.7, -0.85, 0.0, 0.85, 1.7)
        val r = px(106)
        val s = px(50)
        val onRight = cx > sw / 2
        ITEMS.forEachIndexed { i, (icon, label) ->
            val a = base + offs[i]
            val x = (cx + cos(a) * r - s / 2).toInt().coerceIn(px(4), sw - s - px(4))
            val y = (cy + sin(a) * r - s / 2).toInt().coerceIn(px(4), sh - s - px(4))
            val v = circle(icon, if (i == 4 && secret) Color.parseColor("#E5383B") else Color.parseColor("#444B5A"), 50, 22f)
            v.setOnClickListener { closeMenu(); onItem(i) }
            wm.addView(v, lp(s, s, x, y)); sats.add(v)
            if (hints) {
                val t = TextView(ui).apply {
                    text = label; textSize = 12f; setTextColor(Color.WHITE)
                    setPadding(px(10), px(6), px(10), px(6))
                    background = GradientDrawable().apply { cornerRadius = px(12).toFloat(); setColor(Color.parseColor("#CC000000")) }
                }
                t.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
                val tw = t.measuredWidth
                val lx = if (onRight) (x - tw - px(6)).coerceAtLeast(px(2)) else x + s + px(6)
                wm.addView(t, lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, lx, y + s / 2 - px(14)))
                sats.add(t)
            }
        }
    }

    private fun closeMenu() { menuOpen = false; sats.forEach { rm(it) }; sats.clear() }

    private fun onItem(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            1 -> voicePanel()
            2 -> historyPanel()
            3 -> screenTranslate(speak = false)
            4 -> toggleSecret()
        }
    }

    // ---------- панели ----------
    private fun closePanel() { rm(panel); panel = null }

    private fun showPanel(title: String, body: String, buttons: List<Pair<String, () -> Unit>> = emptyList()) {
        closePanel()
        val root = LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(12), px(16), px(16))
            background = GradientDrawable().apply { cornerRadius = px(20).toFloat(); setColor(Color.WHITE); setStroke(px(1), Color.LTGRAY) }
            elevation = px(10).toFloat()
        }
        val head = LinearLayout(ui).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ui).apply { text = title; textSize = 18f; setTextColor(Color.BLACK); setTypeface(typeface, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(ui).apply { text = "✕"; textSize = 22f; setTextColor(Color.GRAY); setPadding(px(12), 0, px(4), 0); setOnClickListener { closePanel() } })
        root.addView(head)
        val sv = object : ScrollView(ui) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(px(220), MeasureSpec.AT_MOST))
            }
        }
        sv.addView(TextView(ui).apply { text = body; textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, px(8), 0, px(8)) })
        root.addView(sv)
        buttons.forEach { (label, act) ->
            root.addView(Button(ui).apply { text = label; isAllCaps = false; setOnClickListener { act() } },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val p = lp(sw - px(24), WindowManager.LayoutParams.WRAP_CONTENT, px(12), 0)
        p.gravity = Gravity.BOTTOM or Gravity.START; p.y = px(24)
        wm.addView(root, p); panel = root
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun needAccessibility() {
        showPanel("Нужна служба доступа",
            "Чтобы читать текст на экране других приложений и распознавать фото, включите службу «Плавающая кнопка» в специальных возможностях.",
            listOf("Открыть настройки" to {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }))
    }

    // ---------- озвучка ----------
    private fun voicePanel() {
        val btns = mutableListOf<Pair<String, () -> Unit>>()
        btns.add(if (listening) "⏹ Остановить озвучку видео" to { stopListen(); closePanel() }
                 else "🎬 Видео и звук (слушаю микрофон)" to { closePanel(); startListen() })
        btns.add("📝 Текст на экране" to { closePanel(); screenTranslate(speak = true) })
        btns.add("🖼️ Фото и картинка (распознать текст)" to { closePanel(); photo() })
        showPanel("Что озвучить?",
            "${Prefs.name(Prefs.src(this))} → ${Prefs.name(Prefs.dst(this))}. Для видео включите ролик и поднесите звук к микрофону или уменьшите громкость оригинала.",
            btns)
    }

    private fun startListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Разрешите микрофон в приложении"); onItem(0); return
        }
        listening = true
        bubble?.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E5383B")) }
        eng.startListening(Prefs.src(this), { t -> main.post { handle(t, speak = true, panelResult = false) } },
            { main.post { stopListen(); toast("Распознавание речи недоступно или нет доступа к микрофону") } })
        toast("Слушаю… Нажмите 🎙️, чтобы остановить")
    }

    private fun stopListen() {
        listening = false
        eng.stopListening(); eng.stopSpeak()
        bubble?.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2F5BFF")) }
    }

    private fun screenTranslate(speak: Boolean) {
        val svc = ScreenAccessibilityService.instance
        if (svc == null) { needAccessibility(); return }
        val text = svc.collectText()
        if (text.isBlank()) { toast("На экране не найден текст"); return }
        handle(text.take(3000), speak, panelResult = true)
    }

    private fun photo() {
        val svc = ScreenAccessibilityService.instance
        if (svc == null) { needAccessibility(); return }
        if (Build.VERSION.SDK_INT < 30) { toast("Снимок экрана доступен на Android 11 и новее"); return }
        setHidden(true)
        main.postDelayed({
            svc.screenshot { bmp ->
                main.post {
                    setHidden(false)
                    if (bmp == null) toast("Не удалось сделать снимок экрана")
                    else eng.ocr(bmp) { t ->
                        if (t.isBlank()) toast("Текст на картинке не найден (поддерживается латиница, китайский, японский, корейский, деванагари)")
                        else handle(t.take(3000), speak = true, panelResult = true)
                    }
                }
            }
        }, 300)
    }

    private fun setHidden(h: Boolean) {
        val v = if (h) View.INVISIBLE else View.VISIBLE
        bubble?.visibility = v; panel?.visibility = v
    }

    private fun handle(text: String, speak: Boolean, panelResult: Boolean) {
        val s = Prefs.src(this); val d = Prefs.dst(this)
        if (secret) {
            val line = FAKE[fi++ % FAKE.size]
            Prefs.addHistory(this, text, line, s, "ru")
            if (panelResult) showPanel("🤫 Перевод (шутка)", line, listOf("🔊 Озвучить" to { eng.speak(line, "ru") }))
            else toast(line)
            if (speak) eng.speak(line, "ru")
            return
        }
        eng.translate(text, s, d) { tr ->
            main.post {
                if (tr == null) {
                    toast("Не удалось перевести. Для первого запуска языка нужен интернет (модель около 30 МБ).")
                } else {
                    Prefs.addHistory(this, text, tr, s, d)
                    if (panelResult) showPanel("Перевод", tr, listOf("🔊 Озвучить" to { eng.speak(tr, d) }))
                    else toast(tr)
                    if (speak) eng.speak(tr, d)
                }
            }
        }
    }

    private fun toggleSecret() {
        secret = !secret
        if (secret) {
            val line = FAKE[fi++ % FAKE.size]
            showPanel("🤫 Секретная кнопка включена",
                "Это шутка: теперь «перевод» и озвучка врут и показывают выдуманную рекламу.\n\n$line",
                listOf("Выключить" to { secret = false; closePanel() }))
        } else { closePanel(); toast("Секретная кнопка выключена") }
    }

    private fun historyPanel() {
        val h = Prefs.history(this)
        if (h.isEmpty()) { showPanel("История озвучки", "Пока пусто. Всё озвученное появится здесь."); return }
        val df = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault())
        val body = h.reversed().take(20).joinToString("\n\n") {
            "${df.format(java.util.Date(it.getLong("t")))}  ${Prefs.name(it.getString("s"))} → ${Prefs.name(it.getString("d"))}\n${it.getString("tr")}\n(${it.getString("o").take(80)})"
        }
        val last = h.last()
        showPanel("История озвучки", body, listOf(
            "🔊 Озвучить последнее" to { eng.speak(last.getString("tr"), last.getString("d")) },
            "🗑 Очистить историю" to { Prefs.clearHistory(this); closePanel() }
        ))
    }

    override fun onDestroy() {
        closeMenu(); closePanel(); showKill(false); rm(bubble)
        eng.shutdown()
        super.onDestroy()
    }
}
