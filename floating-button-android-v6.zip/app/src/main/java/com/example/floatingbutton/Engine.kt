package com.example.floatingbutton

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

/** Озвучка, перевод, распознавание речи и текста на фото. */
class Engine(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var wantListen = false
    private val h = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS }
    }

    fun speak(text: String, lang: String) {
        if (!ttsReady) return
        tts?.language = Locale.forLanguageTag(lang)
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, System.nanoTime().toString())
    }

    fun stopSpeak() { tts?.stop() }

    fun translate(text: String, src: String, dst: String, done: (String?) -> Unit) {
        if (src == dst) { done(text); return }
        val s = TranslateLanguage.fromLanguageTag(src)
        val d = TranslateLanguage.fromLanguageTag(dst)
        if (s == null || d == null) { done(null); return }
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(d).build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { done(it); tr.close() }
                    .addOnFailureListener { done(null); tr.close() }
            }
            .addOnFailureListener { done(null); tr.close() }
    }

    fun ocr(bmp: Bitmap, done: (String) -> Unit) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { done(it.text) }
            .addOnFailureListener { done("") }
    }

    fun startListening(lang: String, onText: (String) -> Unit, onFatal: (Int) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onFatal(-1); return }
        stopListening()
        wantListen = true
        val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = rec
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        }
        fun again(delay: Long) {
            if (!wantListen) return
            h.postDelayed({
                if (wantListen) try { rec.startListening(intent) } catch (_: Exception) {}
            }, delay)
        }
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null && tts?.isSpeaking != true) onText(t)
                again(200)
            }
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { wantListen = false; onFatal(e) }
                else again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 300)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        rec.startListening(intent)
    }

    fun stopListening() {
        wantListen = false
        sr?.destroy()
        sr = null
    }

    fun shutdown() {
        stopListening()
        tts?.shutdown()
    }
}
